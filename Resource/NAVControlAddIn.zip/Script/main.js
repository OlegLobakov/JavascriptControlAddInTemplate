﻿let navControlContainer;
let AddInReady = false;

function InitializeControlAddIn() {

    navControlContainer = $("#controlAddIn"); 
    AddInReady = true;
    RaiseCALEvent('ControlAddIsReady', []);
}

//Update Data from NAV
function Update() {
    try {
        let x = 0;
    } catch (err) {
        RaiseCALEvent('OnError', ["Javascript error :" + err]);
    }
    RaiseCALEvent('OnUpdate', []);
}

function RaiseCALEvent(eventName, args) {
    /// <summary>Raises an event trigger in C/AL` code.</summary>
    /// <param name="eventName">Name of the C/AL event trigger. The event must belong to the control and be declared in the IAdvancedExtensibilityControl interface.</param>
    /// <param name="args">Any event trigger parameters to pass to C/AL. This parameter is always of the array type, so you must enclose it in [].</param>
    Microsoft.Dynamics.NAV.InvokeExtensibilityMethod(eventName, args);
}

window.__controlAddInError__NAV = window.__controlAddInError;
window.__controlAddInError = function (e) {
    console.log("Unhandled error has occurred: '" + e.message + "' - Stack: " + e.stack);
    window.__controlAddInError__NAV(e);
};